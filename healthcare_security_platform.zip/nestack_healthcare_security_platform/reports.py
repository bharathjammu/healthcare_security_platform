from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import mm

def build_pdf(record, path):
    styles = getSampleStyleSheet()
    story = [Paragraph("Healthcare Web & API Security Assessment", styles["Title"]),
             Spacer(1, 5*mm),
             Paragraph(f"Assessment ID: {record['id']}<br/>Target: {record['target']}<br/>Date: {record['created_at']}", styles["BodyText"]),
             Spacer(1, 5*mm),
             Paragraph("Executive Summary", styles["Heading2"])]
    summary = record["result"]["summary"]
    data = [["Severity", "Count"]] + [[k, str(summary.get(k, 0))] for k in ["Critical","High","Medium","Low","Info"]]
    table = Table(data, colWidths=[65*mm, 35*mm])
    table.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#172554")),
                               ("TEXTCOLOR",(0,0),(-1,0),colors.white),
                               ("GRID",(0,0),(-1,-1),0.5,colors.grey),
                               ("PADDING",(0,0),(-1,-1),7)]))
    story += [table, Spacer(1, 5*mm), Paragraph("Findings", styles["Heading2"])]
    for i, f in enumerate(record["result"]["findings"], 1):
        story += [Paragraph(f"{i}. {f['title']} [{f['severity']}]", styles["Heading3"]),
                  Paragraph(f"<b>Category:</b> {f['category']}<br/><b>Evidence:</b> {f['evidence']}<br/><b>Recommendation:</b> {f['recommendation']}", styles["BodyText"]),
                  Spacer(1, 3*mm)]
    story += [Spacer(1, 4*mm), Paragraph(record["result"]["scope_note"], styles["Italic"]),
              Paragraph("Limitations: automated baseline checks only. Results require human validation and do not constitute a penetration test or compliance certification.", styles["Italic"])]
    SimpleDocTemplate(path, pagesize=A4, rightMargin=18*mm, leftMargin=18*mm, topMargin=16*mm, bottomMargin=16*mm).build(story)
