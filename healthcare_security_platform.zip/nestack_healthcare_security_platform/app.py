import os
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, send_file, jsonify
from werkzeug.utils import secure_filename
from database import init_db, get_db, save_scan, get_scan, list_scans
from scanner import run_assessment
from reports import build_pdf

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-for-local-development")
app.config["DATABASE"] = os.environ.get("DATABASE_PATH", "instance/assessments.db")
app.config["REPORT_DIR"] = os.environ.get("REPORT_DIR", "reports")
os.makedirs("instance", exist_ok=True)
os.makedirs(app.config["REPORT_DIR"], exist_ok=True)

with app.app_context():
    init_db(app.config["DATABASE"])

@app.get("/")
def index():
    scans = list_scans(app.config["DATABASE"])
    return render_template("index.html", scans=scans)

@app.get("/demo")
def demo():
    return render_template("demo.html")

# Deliberately simplified local demo endpoints for assessment practice.
# They contain synthetic data only. Do not add real patient information.
@app.get("/lab/api/patients")
def lab_patients():
    return jsonify({"patients": [
        {"id": "P-1001", "name": "Sample Patient A", "condition": "Demo only"},
        {"id": "P-1002", "name": "Sample Patient B", "condition": "Demo only"}
    ]})

@app.get("/lab/api/profile")
def lab_profile():
    return jsonify({"user": "demo-user", "role": "viewer", "note": "Synthetic lab response"})

@app.post("/scan")
def scan():
    target = request.form.get("target", "").strip()
    # Strict scope: only this application's local lab target is accepted.
    allowed = {"http://127.0.0.1:5000", "http://localhost:5000"}
    if target not in allowed:
        flash("For safety, scans are restricted to the local demo app: http://127.0.0.1:5000", "error")
        return redirect(url_for("index"))
    result = run_assessment(target)
    scan_id = save_scan(app.config["DATABASE"], target, result)
    flash("Assessment completed. Review the findings below.", "success")
    return redirect(url_for("scan_detail", scan_id=scan_id))

@app.get("/scan/<int:scan_id>")
def scan_detail(scan_id):
    record = get_scan(app.config["DATABASE"], scan_id)
    if not record:
        return "Assessment not found", 404
    return render_template("detail.html", record=record)

@app.get("/scan/<int:scan_id>/report")
def report(scan_id):
    record = get_scan(app.config["DATABASE"], scan_id)
    if not record:
        return "Assessment not found", 404
    path = os.path.join(app.config["REPORT_DIR"], f"assessment_{scan_id}.pdf")
    build_pdf(record, path)
    return send_file(path, as_attachment=True, download_name=f"healthcare_security_assessment_{scan_id}.pdf")

@app.get("/health")
def health():
    return jsonify({"status": "ok", "service": "Nestack Healthcare Security Assessment Lab"})

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
