from urllib.parse import urljoin
import requests

TIMEOUT = 5

def _finding(title, severity, category, evidence, recommendation):
    return {"title": title, "severity": severity, "category": category,
            "evidence": evidence, "recommendation": recommendation}

def run_assessment(base_url):
    """Non-destructive checks against the explicitly scoped local lab only."""
    session = requests.Session()
    session.headers.update({"User-Agent": "Nestack-Healthcare-Security-Lab/1.0"})
    findings = []
    checked = []

    routes = ["/", "/demo", "/health", "/lab/api/patients", "/lab/api/profile"]
    responses = {}
    for route in routes:
        try:
            response = session.get(urljoin(base_url, route), timeout=TIMEOUT)
            responses[route] = response
            checked.append({"path": route, "status": response.status_code})
        except requests.RequestException as exc:
            findings.append(_finding(
                f"Endpoint unavailable: {route}", "Info", "Availability",
                str(exc)[:180], "Confirm the local lab is running and repeat the assessment."
            ))

    root = responses.get("/")
    if root is not None:
        headers = root.headers
        header_checks = [
            ("Content-Security-Policy", "High", "Add a restrictive Content-Security-Policy to reduce script injection impact."),
            ("X-Content-Type-Options", "Low", "Set X-Content-Type-Options: nosniff."),
            ("X-Frame-Options", "Medium", "Set X-Frame-Options: DENY or use CSP frame-ancestors."),
            ("Referrer-Policy", "Low", "Set a privacy-preserving Referrer-Policy such as strict-origin-when-cross-origin."),
        ]
        for header, severity, recommendation in header_checks:
            if header not in headers:
                findings.append(_finding(
                    f"Missing security header: {header}", severity, "HTTP Security Headers",
                    f"{header} was not present on GET /.", recommendation
                ))
        if headers.get("Server"):
            findings.append(_finding(
                "Server banner disclosed", "Info", "Information Disclosure",
                f"Server header: {headers.get('Server')}", "Consider minimizing unnecessary server/version disclosure."
            ))

    for route in ("/lab/api/patients", "/lab/api/profile"):
        response = responses.get(route)
        if response is None:
            continue
        if response.status_code == 200:
            findings.append(_finding(
                f"API endpoint responds without authentication: {route}", "High", "API Access Control",
                f"Unauthenticated GET returned HTTP {response.status_code}. Data is synthetic in this lab.",
                "Require authentication and enforce authorization on every API request. Add negative tests for anonymous and cross-role access."
            ))
        if response.headers.get("Access-Control-Allow-Origin") == "*":
            findings.append(_finding(
                f"Wildcard CORS policy: {route}", "Medium", "API Configuration",
                "Access-Control-Allow-Origin: *", "Restrict CORS to trusted application origins; avoid wildcard access for sensitive APIs."
            ))

    if not findings:
        findings.append(_finding("No issues detected by baseline checks", "Info", "Assessment Coverage",
                                 "The configured passive checks did not identify issues.",
                                 "This is not proof of security. Perform manual review and broader authorized testing."))

    counts = {s: sum(1 for f in findings if f["severity"] == s) for s in ["Critical", "High", "Medium", "Low", "Info"]}
    return {
        "created_at": __import__("datetime").datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "summary": counts,
        "findings": findings,
        "checked": checked,
        "scope_note": "Local synthetic lab only. Passive checks; no exploitation or destructive payloads."
    }
