# Nestack Healthcare Web & API Security Assessment Platform

A portfolio-ready, Python/Flask project demonstrating passive security assessment workflows for a **synthetic local healthcare application**. It checks baseline HTTP security headers and selected API access-control behaviors, stores assessment history in SQLite, and generates PDF reports.

> **Safety and scope:** The scanner is deliberately restricted by the web interface to `http://127.0.0.1:5000` or `http://localhost:5000`. It performs non-destructive GET requests only. Use synthetic data. Do not scan systems you do not own or have explicit written authorization to test. This is a learning/portfolio tool, not a certified vulnerability scanner or HIPAA compliance tool.

## Features
- Flask dashboard and assessment history
- Synthetic healthcare API endpoints for lab testing
- Passive checks for CSP, `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, server banner, unauthenticated API responses, and wildcard CORS
- Severity summary (Critical/High/Medium/Low/Info)
- SQLite persistence
- Downloadable PDF report
- Clear scope and limitations in reports

## Requirements
- Python 3.10+
- pip

## Setup (Windows PowerShell)
```powershell
cd nestack_healthcare_security_platform
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python app.py
```

## Setup (Linux/macOS)
```bash
cd nestack_healthcare_security_platform
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000`. Visit **Demo Lab** to inspect the synthetic portal, then run an assessment using the prefilled local target. Open a finding to view details and download the PDF report.

## Project structure
```text
app.py                 Flask routes and application entry point
scanner.py             Passive assessment checks
database.py            SQLite persistence
reports.py             PDF report generation
templates/             HTML templates
static/style.css       Dashboard styling
instance/               Local SQLite database (created automatically)
reports/                Generated PDF reports
```

## Assessment workflow
1. Start the Flask app.
2. Confirm the demo portal loads at `/demo`.
3. From the dashboard, submit `http://127.0.0.1:5000`.
4. Review findings and recommendations.
5. Download the PDF report.
6. Validate each finding manually and document false positives.

## How to extend responsibly
- Add authentication and role-based access tests to a separate local test fixture.
- Add OWASP ZAP baseline integration only after reviewing its configuration and restricting it to an authorized test target.
- Add Nmap only for a dedicated local lab/container network and an explicit allowlist.
- Add unit tests for every detection rule and remediation.
- Never upload real patient data or secrets to the demo.

## Interview explanation (60 seconds)
"I built a Flask-based healthcare security assessment platform for a synthetic patient portal. It performs passive checks for missing HTTP security headers and API access-control weaknesses, classifies findings by severity, stores assessment history in SQLite, and generates PDF reports with evidence and remediation guidance. I restricted the scanner to localhost and used synthetic records so testing remains safe. The next stage is adding authenticated role-based test cases and integrating OWASP ZAP in a controlled lab."

## Important limitations
- The current checks are baseline indicators, not proof of exploitability.
- A `200` response from a demo API is flagged because the lab endpoint is intentionally public; in a real system, confirm expected access policy before classifying it as a vulnerability.
- No real patient records, production systems, active exploit payloads, or compliance claims are included.
