import sqlite3, json, os

def _connect(path):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    return conn

def init_db(path):
    with _connect(path) as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            target TEXT NOT NULL,
            created_at TEXT NOT NULL,
            result_json TEXT NOT NULL
        )""")

def save_scan(path, target, result):
    with _connect(path) as conn:
        cur = conn.execute("INSERT INTO scans(target, created_at, result_json) VALUES (?, ?, ?)",
                           (target, result["created_at"], json.dumps(result)))
        return cur.lastrowid

def get_scan(path, scan_id):
    with _connect(path) as conn:
        row = conn.execute("SELECT * FROM scans WHERE id=?", (scan_id,)).fetchone()
    if not row: return None
    return {"id": row["id"], "target": row["target"], "created_at": row["created_at"],
            "result": json.loads(row["result_json"])}

def list_scans(path):
    with _connect(path) as conn:
        rows = conn.execute("SELECT id, target, created_at, result_json FROM scans ORDER BY id DESC LIMIT 10").fetchall()
    output = []
    for row in rows:
        result = json.loads(row["result_json"])
        output.append({"id": row["id"], "target": row["target"], "created_at": row["created_at"],
                       "total": len(result.get("findings", [])),
                       "high": result.get("summary", {}).get("High", 0)})
    return output
